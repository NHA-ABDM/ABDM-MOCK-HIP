package in.gov.abdm.hip.enums;

public enum AccessMode  {
    VIEW, STORE, QUERY, STREAM;
}