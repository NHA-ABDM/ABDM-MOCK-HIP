package in.gov.abdm.hip.domain.model.consent.notify;

public class Identifier {

    private String value;
    private String type;
    private String system;
}