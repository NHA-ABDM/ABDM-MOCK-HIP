package in.gov.abdm.hip.domain.model.consent.revoke;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsentArtefactId {
    private String id;
}
