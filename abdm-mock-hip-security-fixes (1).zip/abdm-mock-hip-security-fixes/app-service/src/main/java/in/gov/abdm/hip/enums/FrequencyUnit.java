package in.gov.abdm.hip.enums;

public enum FrequencyUnit  {
    HOUR, WEEK, DAY, MONTH, YEAR;
}
