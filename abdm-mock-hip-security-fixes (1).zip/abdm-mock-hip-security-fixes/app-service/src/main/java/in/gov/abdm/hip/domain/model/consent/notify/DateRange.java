package in.gov.abdm.hip.domain.model.consent.notify;

public class DateRange  {

    private String from;
    private String to;
}