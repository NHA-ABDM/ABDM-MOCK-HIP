package in.gov.abdm.hip.domain.model.consent.notify;

import in.gov.abdm.hip.enums.FrequencyUnit;

public class Frequency {

    private FrequencyUnit unit;
    private String value;
    private String repeats;
}